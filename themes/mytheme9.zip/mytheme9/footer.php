<footer class="myfoot">
<?php bloginfo( 'name' ); ?>
</footer>

<?php wp_footer(); ?>
</body>
</html>